# AGENTS.md — Baza (ГОСТ/ISO bearing database)

## Project overview
Baza — машиночитаемая база подшипников ГОСТ/ISO с аналогами и брендами. Истина — в CSV в `data/`, но обновлять их вручную запрещено: изменения вносятся через пайплайн обновления.

## Source of truth
- `INDEX.md`, `RULES.md`, `SOURCES.md` — правила и навигация по данным/источникам.
- `sources/` — исходники (PDF/DOCX) + метаданные `meta.yaml`.
- `schemas/` — схемы таблиц (YAML).
- `scripts/` — обновление и валидация.
- `tests/` — регрессионные проверки формата, сортировки, ключей.

## Golden rules
1) Никогда не редактируй `data/**/*.csv` руками.
2) Единственный путь обновления данных — `scripts/update_repo.py`.
3) После любого изменения данных обязателен прогон валидаторов и тестов.
4) Любые новые данные должны быть трассируемы к источникам из `sources/` и отражены в отчёте `data/reports/`.

## Commands (local)
- Install: `python -m pip install -r requirements.txt`
- Update CSV: `python scripts/update_repo.py --no-report`
- Validate: `python scripts/validate/run_validations.py`
- Tests: `python -m pytest -q`

## Data layout (high level)
- ГОСТ: `data/gost/*`
- ISO: `data/iso/*`
- Аналоги: `data/analogs/*`
- Бренды: `data/brands/*`

## Output discipline
- Таблицы в документации — только короткие значения.
- Большие таблицы — только в `data/` (и то через пайплайн), не в `docs/`.

## Quality bar (done criteria)
- Валидаторы и тесты проходят.
- Нет нарушений ключей/сортировки/формата CSV.
- Есть трассируемость по источникам.
- Документация обновлена только там, где это требуется.
