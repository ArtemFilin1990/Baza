# Skills (Baza)

## Skills
- baza-data-update — обновление данных через пайплайн
- baza-validation — валидаторы и тесты
- baza-schema-evolution — схемы и валидаторы
- baza-docs-generator — docs/INDEX без полноразмерных таблиц
- baza-analogs-gost-iso — аналоги ГОСТ⇄ISO
- encyclopedia-gost-iso — энциклопедический вывод ГОСТ⇄ISO
