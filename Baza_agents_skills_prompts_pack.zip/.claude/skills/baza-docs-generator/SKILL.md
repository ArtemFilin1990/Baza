---
name: baza-docs-generator
description: Обновление docs/ и индексных файлов без дублирования полноразмерных таблиц.
triggers:
  - "docs/"
  - "INDEX.md"
  - "README"
  - "описание данных"
output_formats:
  - md
---

# Skill — Baza Docs Generator

## Rules
- В `docs/` — только обзор/правила/примеры.
- Таблицы в docs — только короткие (колонки/ключи/примеры).

## Output
- Обновлённые описания наборов данных.
- Согласованные пути на `data/` и `schemas/`.
