---
name: baza-schema-evolution
description: Эволюция схем YAML и связанных валидаторов/тестов без поломки контрактов.
triggers:
  - "schemas/"
  - "уникальный ключ"
  - "колонки"
  - "валидация"
output_formats:
  - md
---

# Skill — Baza Schema Evolution

## Workflow
1) Определи CSV (см. `INDEX.md`).
2) Обнови `schemas/*.yaml`.
3) Обнови `scripts/validate/*`.
4) Обнови `tests/*` (ключи и сортировка).
5) Прогони skill `baza-validation`.

## Output
- Колонки/типы/ключи: что изменилось.
- Какие валидаторы/тесты обновлены.
