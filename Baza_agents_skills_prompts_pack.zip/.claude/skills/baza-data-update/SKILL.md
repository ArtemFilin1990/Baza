---
name: baza-data-update
description: Обновление данных Baza (CSV) через официальный пайплайн, без ручных правок.
triggers:
  - "update_repo.py"
  - "обнови данные"
  - "CSV"
  - "data/"
  - "sources/"
  - "meta.yaml"
output_formats:
  - md
---

# Skill — Baza Data Update

## Non-negotiable
- Запрещено редактировать `data/**/*.csv` руками.
- Единственный путь обновления данных — `python scripts/update_repo.py`.

## Workflow
1) Прочитай `RULES.md` и `INDEX.md`.
2) Добавь/обнови источник в `sources/` (и `meta.yaml`, если требуется).
3) Запусти: `python scripts/update_repo.py --no-report` (если допустимо).
4) Прогони: `python scripts/validate/run_validations.py` и `python -m pytest -q`.

## Output
- Какие CSV затронуты.
- Краткое резюме изменений (строки/наборы данных, если доступно).
