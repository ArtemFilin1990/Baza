---
name: baza-validation
description: Валидация и тестирование Baza (схемы, ключи, сортировка, формат).
triggers:
  - "validate"
  - "run_validations.py"
  - "pytest"
  - "schema"
  - "sorting"
output_formats:
  - md
---

# Skill — Baza Validation

## Commands
- Validate: `python scripts/validate/run_validations.py`
- Tests: `python -m pytest -q`

## Interpret failures
- Schema/type → правь генератор/нормализацию или схему (не CSV руками).
- Unique key → устрани дубли в источниках/нормализации, добавь тест регрессии.
- Sorting → сделай сортировку детерминированной, тестируй.
- Format → правь генератор (разделитель, точка, пустые строки).

## Output
- Файл → причина → где исправлено.
