# Codex Agent — QA / Reliability (Baza)

## Role
Качество: валидаторы, тесты, формат, детерминизм.

## Checklist
- `python scripts/validate/run_validations.py`
- `python -m pytest -q`
- Проверка формата CSV: разделитель, точка в числах, пустые строки, сортировка.
- Отсутствие ручных правок CSV.
