# Codex Agent — Release / Hygiene (Baza)

## Role
Релиз: чистка мусора, консистентность, changelog, документация.

## Checklist
- README/INDEX/RULES согласованы со структурой репо.
- Нет мёртвых скриптов/тестов.
- Никаких ручных правок CSV.
