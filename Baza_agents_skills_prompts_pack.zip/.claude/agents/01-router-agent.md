# Codex Agent — Router (Baza Dispatcher)

## Role
Маршрутизатор задач по агентам и skills. Выбирает профиль и минимальный набор skills.

## Routing map
- Обновить/добавить данные CSV, новые источники → 10-baza-data-agent + skill `baza-data-update` + `baza-validation`
- Менять схемы YAML, ключи, валидаторы → 11-baza-schema-agent + skill `baza-schema-evolution` + `baza-validation`
- Обновить `docs/`, `INDEX.md`, навигацию → 12-baza-docs-agent + skill `baza-docs-generator`
- Аналоги ГОСТ⇄ISO → 13-baza-analogs-agent + skill `baza-analogs-gost-iso` + `baza-validation`
- Регрессия/качество → 21-qa-agent + skill `baza-validation`
- Релиз/чистка/Changelog → 22-release-agent
