# Agents (Baza)

Агенты для Codex/Claude Code. Используй Router для выбора профиля под задачу.

## Agents
- 00-core-agent.md — базовый профиль
- 01-router-agent.md — маршрутизация
- 10-baza-data-agent.md — обновление данных/пайплайн
- 11-baza-schema-agent.md — схемы/валидаторы
- 12-baza-docs-agent.md — документация/индексация
- 13-baza-analogs-agent.md — аналоги ГОСТ⇄ISO
- 21-qa-agent.md — проверки/регрессия
- 22-release-agent.md — релиз/чистка/Changelog
