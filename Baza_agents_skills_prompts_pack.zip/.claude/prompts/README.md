# Prompts (Baza)

Шаблоны запросов для Codex/агентов.
