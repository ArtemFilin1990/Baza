# Task Prompt Template — Baza (Codex)

## Goal
(измеримый результат)

## Context
- Что меняем и зачем
- Какие пути затрагиваем

## Requirements
- MUST:
- SHOULD:
- MUST NOT:

## Source of truth
- Файлы, которые агент обязан прочитать

## Deliverables
- Файлы/артефакты

## Validation
- `python scripts/validate/run_validations.py`
- `python -m pytest -q`

## Notes
- Не править `data/**/*.csv` руками.
